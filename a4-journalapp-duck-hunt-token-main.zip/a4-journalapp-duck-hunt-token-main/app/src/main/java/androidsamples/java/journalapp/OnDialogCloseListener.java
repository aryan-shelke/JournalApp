package androidsamples.java.journalapp;

public interface OnDialogCloseListener  {
        void onDateDialogClose();

        void onStartTimeDialogClose();

        void onEndTimeDialogClose();

        void onDeleteEntryDialogClose();

}
